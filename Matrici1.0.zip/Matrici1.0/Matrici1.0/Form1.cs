﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matrici1._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnMatrice_Click(object sender, EventArgs e)
        {
            int colonne=Int32.Parse(NConsumatori.Text);
            int righe= Int32.Parse(NProduttori.Text);
            Tabella.RowCount = righe + 1;
            Tabella.ColumnCount = colonne + 1;
            for(int i=0; i<righe; i++)
            {
                Tabella.Rows[i].HeaderCell.Value = "Produttore" + (i + 1);
            }
            for (int i = 0; i < colonne; i++)
            {
                Tabella.Columns[i].HeaderCell.Value = "Consumatore" + (i + 1);
            }
            Tabella.RowHeadersWidth = 100;
            Tabella.Rows[righe].HeaderCell.Value = "Fabbisogno";
            Tabella.Columns[colonne].HeaderCell.Value = "Produttore";


        }
    }
}
