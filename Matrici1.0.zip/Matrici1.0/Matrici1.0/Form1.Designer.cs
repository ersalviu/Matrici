﻿namespace Matrici1._0
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnMatrice = new System.Windows.Forms.Button();
            this.NConsumatori = new System.Windows.Forms.NumericUpDown();
            this.NProduttori = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.MinProduzione = new System.Windows.Forms.NumericUpDown();
            this.MinCosti = new System.Windows.Forms.NumericUpDown();
            this.BtnGenera = new System.Windows.Forms.Button();
            this.MaxProduzione = new System.Windows.Forms.NumericUpDown();
            this.MaxCosti = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Tabella = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NConsumatori)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NProduttori)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinProduzione)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinCosti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxProduzione)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxCosti)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tabella)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnMatrice);
            this.groupBox1.Controls.Add(this.NConsumatori);
            this.groupBox1.Controls.Add(this.NProduttori);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(29, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 99);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Impostazione Produttori/Consumatori";
            // 
            // BtnMatrice
            // 
            this.BtnMatrice.Location = new System.Drawing.Point(235, 32);
            this.BtnMatrice.Name = "BtnMatrice";
            this.BtnMatrice.Size = new System.Drawing.Size(76, 58);
            this.BtnMatrice.TabIndex = 4;
            this.BtnMatrice.Text = "Crea\r\n Matrice";
            this.BtnMatrice.UseVisualStyleBackColor = true;
            this.BtnMatrice.Click += new System.EventHandler(this.BtnMatrice_Click);
            // 
            // NConsumatori
            // 
            this.NConsumatori.Location = new System.Drawing.Point(169, 70);
            this.NConsumatori.Name = "NConsumatori";
            this.NConsumatori.Size = new System.Drawing.Size(43, 20);
            this.NConsumatori.TabIndex = 3;
            // 
            // NProduttori
            // 
            this.NProduttori.Location = new System.Drawing.Point(169, 35);
            this.NProduttori.Name = "NProduttori";
            this.NProduttori.Size = new System.Drawing.Size(44, 20);
            this.NProduttori.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numero di Consumatori\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero di Produttori";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.MinProduzione);
            this.groupBox2.Controls.Add(this.MinCosti);
            this.groupBox2.Controls.Add(this.BtnGenera);
            this.groupBox2.Controls.Add(this.MaxProduzione);
            this.groupBox2.Controls.Add(this.MaxCosti);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(400, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(374, 99);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Genera Valori Casuali";
            // 
            // MinProduzione
            // 
            this.MinProduzione.Location = new System.Drawing.Point(163, 68);
            this.MinProduzione.Name = "MinProduzione";
            this.MinProduzione.Size = new System.Drawing.Size(44, 20);
            this.MinProduzione.TabIndex = 6;
            // 
            // MinCosti
            // 
            this.MinCosti.Location = new System.Drawing.Point(163, 32);
            this.MinCosti.Name = "MinCosti";
            this.MinCosti.Size = new System.Drawing.Size(44, 20);
            this.MinCosti.TabIndex = 5;
            // 
            // BtnGenera
            // 
            this.BtnGenera.Location = new System.Drawing.Point(292, 32);
            this.BtnGenera.Name = "BtnGenera";
            this.BtnGenera.Size = new System.Drawing.Size(76, 58);
            this.BtnGenera.TabIndex = 4;
            this.BtnGenera.Text = "Genera";
            this.BtnGenera.UseVisualStyleBackColor = true;
            // 
            // MaxProduzione
            // 
            this.MaxProduzione.Location = new System.Drawing.Point(227, 70);
            this.MaxProduzione.Name = "MaxProduzione";
            this.MaxProduzione.Size = new System.Drawing.Size(43, 20);
            this.MaxProduzione.TabIndex = 3;
            // 
            // MaxCosti
            // 
            this.MaxCosti.Location = new System.Drawing.Point(227, 32);
            this.MaxCosti.Name = "MaxCosti";
            this.MaxCosti.Size = new System.Drawing.Size(44, 20);
            this.MaxCosti.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "Range Produzione/Fabbisogni\r\n\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Range Costi";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(29, 158);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(739, 250);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Tabella);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(731, 224);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Matrice Start";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Tabella
            // 
            this.Tabella.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Tabella.Location = new System.Drawing.Point(0, 0);
            this.Tabella.Name = "Tabella";
            this.Tabella.Size = new System.Drawing.Size(731, 228);
            this.Tabella.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(731, 224);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Metodo Nord Ovest";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Ottimizzazione dei  Trasporti ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NConsumatori)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NProduttori)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinProduzione)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinCosti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxProduzione)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxCosti)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Tabella)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnMatrice;
        private System.Windows.Forms.NumericUpDown NConsumatori;
        private System.Windows.Forms.NumericUpDown NProduttori;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown MinProduzione;
        private System.Windows.Forms.NumericUpDown MinCosti;
        private System.Windows.Forms.Button BtnGenera;
        private System.Windows.Forms.NumericUpDown MaxProduzione;
        private System.Windows.Forms.NumericUpDown MaxCosti;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView Tabella;
        private System.Windows.Forms.TabPage tabPage2;
    }
}

